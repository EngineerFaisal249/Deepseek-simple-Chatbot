function sendMessage() {
    let userInput = document.getElementById("userInput").value.trim();
    if (userInput === "") return;

    let chatbox = document.getElementById("chatbox");
    chatbox.innerHTML += `<div class="user-message"><b>You:</b> ${userInput}</div>`;
    document.getElementById("userInput").value = "";
    chatbox.scrollTop = chatbox.scrollHeight;

    fetch("/chat", {
        method: "POST",
        body: JSON.stringify({ message: userInput }),
        headers: { "Content-Type": "application/json" }
    })
    .then(response => response.json())
    .then(data => {
        chatbox.innerHTML += `<div class="bot-message"><b>Bot:</b> ${data.response}</div>`;
        chatbox.scrollTop = chatbox.scrollHeight;
    });
}

function uploadImage() {
    let file = document.getElementById("imageUpload").files[0];
    alert("Image uploaded: " + file.name);
}

function uploadFile() {
    let file = document.getElementById("fileUpload").files[0];
    alert("File uploaded: " + file.name);
}

function startVoice() {
    let recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
    recognition.lang = 'en-US';
    recognition.start();

    recognition.onresult = function(event) {
        document.getElementById("userInput").value = event.results[0][0].transcript;
    };
}

function startWebcam() {
    let video = document.getElementById("video");
    video.style.display = "block";

    navigator.mediaDevices.getUserMedia({ video: true })
        .then(stream => {
            video.srcObject = stream;
        })
        .catch(err => {
            alert("Error accessing webcam: " + err);
        });
}

function handleKeyPress(event) {
    if (event.key === "Enter") {
        sendMessage();
    }
}
